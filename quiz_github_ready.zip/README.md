# 📊 Quiz Interativo de Estatística  

Projeto desenvolvido como parte de uma **apresentação da pós-graduação em Data Science e Inteligência Artificial**, unindo **aprendizado acadêmico** com **diversão interativa**.  

Este quiz tem como objetivo reforçar conceitos estatísticos de forma lúdica, oferecendo uma experiência prática em que o usuário pode responder perguntas, testar conhecimentos e aprender de forma dinâmica.  

---

## 🚀 Tecnologias Utilizadas
- **HTML5** → Estrutura da aplicação  
- **CSS3** → Estilização e layout responsivo  
- **JavaScript (ES6+)** → Lógica do quiz e interatividade  

---

## 🎯 Objetivos
- Aproximar teoria e prática em Estatística.  
- Criar um recurso didático para uso em apresentações acadêmicas.  
- Explorar o uso de **JavaScript** para aplicações simples e eficazes.  
- Tornar o processo de aprendizado mais **interativo e atrativo**.  

---

## 📂 Estrutura do Projeto
```
quiz/
 ├── index.html      # Página principal do quiz
 ├── style.css       # Estilos visuais
 ├── script.js       # Lógica do quiz em JavaScript
 └── assets/         # Imagens, ícones e recursos adicionais
```

---

## ▶️ Como Executar
1. Baixe ou clone este repositório:
   ```bash
   git clone https://github.com/SEU_USUARIO/quiz.git
   ```
2. Abra o arquivo `index.html` em qualquer navegador moderno.  
   *(Não é necessário instalar dependências — projeto puramente HTML, CSS e JS.)*

---

## 📸 Demonstração
*(Adicione aqui um print ou GIF da aplicação rodando para deixar o README mais atrativo)*  

---

## 📚 Aprendizados
Durante o desenvolvimento, foram praticados:  
- Estruturação de **quiz interativo** em JavaScript.  
- Manipulação de DOM para exibição dinâmica de perguntas e respostas.  
- Boas práticas de organização de código e separação de responsabilidades.  
- Uso de HTML/CSS/JS puro para criar aplicações funcionais e leves.  

---

## 👨‍💻 Autor
**Elivânio Geraldo**  
📍 Brasília - DF  
🎓 Pós-graduação em Data Science & IA  
🔗 [LinkedIn](https://linkedin.com/in/seu-perfil) | [GitHub](https://github.com/SEU_USUARIO)  

---

## 📄 Licença
Este projeto é de uso **educacional e demonstrativo**.  
Sinta-se à vontade para clonar, adaptar e evoluir a ideia. 🚀
