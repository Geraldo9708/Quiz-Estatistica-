const quizContainer = document.getElementById('quiz');
const resultsContainer = document.getElementById('results');
const submitButton = document.getElementById('submit');

const myQuestions = [
  {
    question: "1) Qual é a média dos números 2, 4, 6, 8, 10?",
    answers: {
      a: "5",
      b: "6",
      c: "7"
    },
    correctAnswer: "b"
  },
  {
    question: "2) Em uma distribuição normal, aproximadamente 95% dos valores estão dentro de quantos desvios-padrão da média?",
    answers: {
      a: "1",
      b: "2",
      c: "3"
    },
    correctAnswer: "b"
  },
  {
    question: "3) A moda é:",
    answers: {
      a: "O valor mais frequente em um conjunto de dados",
      b: "A soma de todos os valores dividida pelo número de observações",
      c: "A medida de dispersão dos dados"
    },
    correctAnswer: "a"
  }
];

function buildQuiz(){
  const output = [];
  myQuestions.forEach((currentQuestion, questionNumber) => {
    const answers = [];
    for(letter in currentQuestion.answers){
      answers.push(
        `<label>
           <input type="radio" name="question${questionNumber}" value="${letter}">
           ${letter} : ${currentQuestion.answers[letter]}
         </label>`
      );
    }
    output.push(
      `<div class="question"> ${currentQuestion.question} </div>
       <div class="answers"> ${answers.join('')} </div>`
    );
  });
  quizContainer.innerHTML = output.join('');
}

function showResults(){
  const answerContainers = quizContainer.querySelectorAll('.answers');
  let numCorrect = 0;

  myQuestions.forEach((currentQuestion, questionNumber) => {
    const answerContainer = answerContainers[questionNumber];
    const selector = `input[name=question${questionNumber}]:checked`;
    const userAnswer = (answerContainer.querySelector(selector) || {}).value;

    if(userAnswer === currentQuestion.correctAnswer){
      numCorrect++;
      answerContainers[questionNumber].style.color = 'green';
    } else {
      answerContainers[questionNumber].style.color = 'red';
    }
  });

  resultsContainer.innerHTML = `${numCorrect} de ${myQuestions.length} corretas`;
}

buildQuiz();
submitButton.addEventListener('click', showResults);
